'use strict';
<<<<<<< HEAD
//const path 	= require('path');

module.exports = {
    malicsi: {
        host: 'localhost',
        user: 'root',
        password: ' ', //change according to machine/ DB pw
        database: 'malicsiDB'
    }
}
=======

module.exports = {
    info: {//configure
        host: '',
        user: 'root',
        password: '', 
        database: 'malicsiDB'
    }
}
>>>>>>> 5a6394d17c265f7ef6d52968c0ac5749adbb4d4a
